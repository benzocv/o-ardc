function anurag1() {
    document.getElementById("anu").style.width = "100%";
}

function anurag2() {
    document.getElementById("anu").style.width = "0%";
}